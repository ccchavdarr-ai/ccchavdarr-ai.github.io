MANOLOV STROY — сайт за GitHub Pages

Потребителско име: ccchavdarr-ai
Очакван адрес: https://ccchavdarr-ai.github.io

Качете index.html в основната директория (root) на repository ccchavdarr-ai.github.io.
Телефонът е зададен на 0884 920 390.

Формата за запитване в момента е примерна и сочи към info@manolovstroy.bg.
Преди да я използвате, заменете адреса с реален имейл или настройте услуга за формуляри.
След публикуване проверете дали сайтът се отваря през HTTPS.
